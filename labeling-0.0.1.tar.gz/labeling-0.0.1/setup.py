# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 16:32:26 2023

@author: wuyiwen
"""

import setuptools
 

 
setuptools.setup(
    name="labeling",
    version="0.0.1",
    author="wu yiwen",
    python_requires='>=3.7',
    install_requires=[ 'tifffile==2023.2.2','scipy==1.10.1','opencv-python==4.7.0.72', 'numpy==1.24.2', 'pandas==1.5']

)