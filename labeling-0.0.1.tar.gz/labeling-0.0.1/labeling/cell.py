# -*- coding: utf-8 -*-
"""
Created on Thu Mar  2 09:30:48 2023

@author: ywu28328
"""
import os
import datetime
import cv2
import gzip
import tifffile as tifi
import numpy as np
import pandas as pd

class Correction(object):
    def __init__(self,mask_path, output_path, gem_path = None):
        self.filename = mask_path.replace('\\','/').split('/')[-1].split('.')[0]
        self.mask_path = mask_path
        self.mask = self.read_mask(mask_path)
        self.output_path = output_path
        self.gem_path = gem_path
        self.gem = None
        self.gef = None
        self.exp_matrix = None # Dataframe
    
    def read_mask(self,mask_path):
        mask = tifi.imread(mask_path)
        mask[mask>0] = 1
        mask = mask.astype(np.uint8)
        return mask
    
    def exp_to_txt(self):
        if not self.exp_matrix:
            self.creat_cell_gxp()
        self.exp_matrix.to_csv(os.path.join(self.output_path, f'{self.fileName}_exp_gene_with_bg.txt'), sep='\t', index=False)
    
    
    def est_para(self):
        _, maskImg = cv2.connectedComponents(self.mask, connectivity=8)
        cell_avg_area = np.count_nonzero(self.mask)/np.max(maskImg)
        if cell_avg_area >= 350:
            print (f'cell average size is {cell_avg_area}, d recommend 5 or 10')
        else:
            radius = int(np.sqrt(400/np.pi) - np.sqrt(cell_avg_area/np.pi))
            print (f'd recommend at least {radius}')
        import psutil
        print (f'processes perfer set to {int(psutil.cpu_count(logical = False) * 0.7)}')
    
    def creat_cell_gxp(self):
        def parse_head(gem):
            if gem.endswith('.gz'):
                f = gzip.open(gem, 'rb')
            else:
                f = open(gem, 'rb')
            num_of_header_lines = 0
            for i, l in enumerate(f):
                l = l.decode("utf-8") # read in as binary, decode first
                if l.startswith('#'): # header lines always start with '#'
                    num_of_header_lines += 1
                else:
                    break
            return num_of_header_lines
        
        if not self.gem_path:
            print ('gem file not exist!')
            return
                
        print("Loading mask file...")
        
        _, maskImg = cv2.connectedComponents(self.mask, connectivity = 8)
        
        print("Reading data..")
    
        header = parse_head(self.gem_path)
        genedf = pd.read_csv(self.gem_path, header=header, sep='\t')
        genedf['x'] -=  genedf['x'].min()
        genedf['y'] -=  genedf['y'].min()
        self.gem = genedf

        if "UMICount" in genedf.columns:
            genedf = genedf.rename(columns={'UMICount':'MIDCount'})
        if "MIDCounts" in genedf.columns:
            genedf = genedf.rename(columns={'MIDCounts':'MIDCount'})

        tissuedf = pd.DataFrame()
        dst = np.nonzero(maskImg)
        
        print("Dumping results...")
        tissuedf['x'] = dst[1] + genedf['x'].min()
        tissuedf['y'] = dst[0] + genedf['y'].min()
        tissuedf['label'] = maskImg[dst]
        
        res = pd.merge(genedf, tissuedf, on=['x', 'y'], how='left').fillna(0) # keep background data
        res['x'] = res['x'].astype(int)
        res['y'] = res['y'].astype(int)
        res['label'] = res['label'].astype(int)
        self.exp_matrix = res
        
    def plot_exp(self, file_type='png'):
        if self.exp_matrix:
            img = np.zeros([self.exp_matrix['y'].max()+1, self.exp_matrix['x'].max()+1],dtype=np.uint8)
            img[self.exp_matrix['y'], self.exp_matrix['x']] = 255
            cv2.imwrite(os.path.join(self.output_path, f'{self.filename}_exp.{file_type}'), img)
        else:
            print ('Exp matrix does not exist...')

    def plot_gem(self, file_type='png'):
        if self.gem:
            img = np.zeros([self.gem['y'].max()+1, self.gem['x'].max()+1],dtype=np.uint8)
            img[self.gem['y'], self.gem['x']] = 255
            cv2.imwrite(os.path.join(self.output_path, f'{self.filename}_gem.{file_type}'), img)
        else:
            print ('Gem matrix does not exist...')
            
